const { addonBuilder } = require('stremio-addon-sdk');
const { createServer } = require('http');

// Create a new add-on using the builder pattern
const builder = new addonBuilder({
    id: 'random-watchlist',
    version: '1.0.0',
    name: 'Random Watchlist',
    description: 'Plays a random show and episodes in order',
    types: ['movie', 'series'],
    resources: ['catalog', 'meta', 'stream'],
    catalogs: [ // Corrected catalogs field as an array
        { type: 'series', id: 'random-watchlist-catalog', name: 'Random Watchlist Catalog' }
    ],
});

// Define the catalog handler (list of shows)
builder.defineCatalogHandler(async () => {
    return {
        metas: [
            { id: '1', name: 'Show A', type: 'series' },
            { id: '2', name: 'Show B', type: 'series' },
            { id: '3', name: 'Show C', type: 'series' }
        ],
    };
});

// Define the meta handler (episodes)
builder.defineMetaHandler(async (args) => {
    return { meta: { id: args.id, name: `Episode ${args.id}`, type: 'episode' } };
});

// Define the stream handler (where to find episodes)
builder.defineStreamHandler(async (args) => {
    return {
        streams: [
            {
                url: `http://localhost:7000/stream/${args.id}`,
                quality: 'HD',
                type: 'video',
                name: `Episode ${args.id}`,
            },
        ],
    };
});

// Start the server
createServer(builder.getInterface()).listen(7000, () => {
    console.log('Stremio Addon listening on http://localhost:7000');
});
